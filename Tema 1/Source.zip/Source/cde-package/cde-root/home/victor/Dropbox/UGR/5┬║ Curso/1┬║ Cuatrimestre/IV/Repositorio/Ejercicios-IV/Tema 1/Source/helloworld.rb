puts 'Hello, world!'
